#ifndef instance_c
#define instance_c

class InstanceCounter{

    public:
        InstanceCounter();
        virtual ~InstanceCounter();

};

#endif